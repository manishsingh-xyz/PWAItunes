import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class ItunesdataService {

  constructor(private http: HttpClient) { }

  // getData(): Observable<Hero[]> {
  //   // Todo: send the message _after_ fetching the heroes
  //   this.messageService.add('HeroService: fetched heroes');
  //   return of(HEROES);
  // }
  getData(query,category) {
    var URL = 'https://itunes.apple.com/search?term=' + query +'&country=us&entity=' + category;
    return this.http.get(URL);
  }

  // search(term:string): Observable<SearchItem[]> { 
  //   console.log("hel");
  //   return true;
  //  }

}
