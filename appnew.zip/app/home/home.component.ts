import { Component, OnInit } from '@angular/core';
import { ItunesdataService } from '../itunesdata.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

 

  ngOnInit() {
  }

  constructor(private itunesdataservice: ItunesdataService) { }

  title = 'iTunes Search ';
  searchedItem:string = '';
  selectedItem:string = 'movie';
  iData =[];

  items = [
    { value: 'movie', viewValue: 'Music & Movies' },
    { value: 'software', viewValue: 'Apps' }
  ];

  SearchItunes(): void {  
      this.itunesdataservice.getData(this.searchedItem,this.selectedItem)
            .subscribe((res) => {
                console.log(res);              
                this.iData = res.results;
              }
            );
  } 

  

}
